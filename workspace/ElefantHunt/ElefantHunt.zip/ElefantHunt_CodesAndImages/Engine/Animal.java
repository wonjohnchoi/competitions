/**
 * @author Gerard Juan
 * @date June 4th, 2010
 * @supervisor Mr. Reid
 * @course ICS4U
 */
//extends Item class with Animal class
public class Animal extends Item 
{
	private boolean isPredator; 
	
	/**
	 * constructor
	 * @param lvl, the level of the item
	 * @param name
	 * @param predator
	 * @author Gerard Juan
	 */
	public Animal (int lvl, String name, boolean predator)
	{	
		super(lvl, name);
		isPredator = predator;
	}
	
	/**
	 * @return if predator or not
	 * @author Gerard Juan
	 */
	public boolean isPredator()
	{	
		return isPredator;
	}	
	
	/**
	 * @return string representation of the animal
	 * @author Gerard Juan
	 */
	public String toString()
	{
		String output = super.toString();
		
		if(isPredator)
		{
			output = "Predator Animal "+output;
		}	
		else
		{
			output = "Friendly Animal "+output;
		}	
		return output;
	}	
}
