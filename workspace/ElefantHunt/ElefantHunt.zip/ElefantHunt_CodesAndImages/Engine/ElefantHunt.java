
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
/**
 * ElefantHunt class that holds the main functions of the game, and the map
 * @author Wonjohn Choi, Philip Markowski
 * @date June , 2010
 * @supervisor Mr. Reid
 * @course ICS4U
 */
public class ElefantHunt 
{
	protected int supplies;
	protected ArrayList<Animal> animalPool;
	protected ArrayList<Hunter> hunterPool;
	protected ArrayList<Player> players;
	protected int [] map;
	protected ElefantHuntMap guimap;
	protected SimpleMessage sm;

	/*
	 * Keep variables as 'final'
	 * They should not be changed during a game
	 */
	protected final int PORT = 0;
	protected final int SPACE = 1;
	protected final int SWAMP = 2;
	protected final int HUNT1 = 3;
	protected final int HUNT2 = 4;
	protected final int HUNT3 = 5;
	protected final int ENDPOINT = 100;
	
	/**
	 * Constructor for the game. Initializes all values.
	 * @author Philip Markowski
	 */
	public ElefantHunt() 
	{		
		//GUI Message
		sm = new SimpleMessage("Message Box created!");

		initializeEngine();
		
		// Gui Map
		guimap = new ElefantHuntMap(players);
	}

	/**
	 * Simplified method to call initializing methods.
	 * @author Philip Markowski
	 */
	public void initializeEngine() 
	{
		intializeSupplies();
		initializeAnimals();
		initializeHunters();
		initializeMap();
		initializePlayers();
	}

	/**
	 * initialize map filling it with data 
	 * @author Wonjohn Choi
	 */
	public void initializeMap()
	{
		//Data is took from the game instruction paper given by the supervisor
		map = new int[] {
				PORT, SPACE, SPACE, HUNT2, SPACE, HUNT2, SPACE, SWAMP, 
				SPACE, SPACE, HUNT1, SPACE, SPACE, HUNT1, HUNT2, SWAMP, 
				SPACE, HUNT3, SWAMP, SPACE, SPACE, HUNT3, SPACE, SPACE, 
				SWAMP, SPACE, SPACE, HUNT1, SPACE
		};
	}

	/**
	 * initialize an ArrayList with the ADT Hunter filling it with data 
	 * @author Wonjohn Choi
	 */
	public void initializeHunters()
	{
		//initialize
		hunterPool = new ArrayList<Hunter>();

		//add sub hunters
		hunterPool.add(new Hunter(2, "Sam Smyle", false));
		hunterPool.add(new Hunter(2, "Colonel", false));
		hunterPool.add(new Hunter(3, "Zartan", false));
		hunterPool.add(new Hunter(3, "Ed Oop", false));
		hunterPool.add(new Hunter(1, "Pistol Pete", false));
		hunterPool.add(new Hunter(2, "Chief", false));
		hunterPool.add(new Hunter(3, "Tom Trap", false));
		hunterPool.add(new Hunter(1, "Twoleft", false));
		hunterPool.add(new Hunter(5, "Aubrey", false));
		hunterPool.add(new Hunter(1, "Fritz", false));
		hunterPool.add(new Hunter(4, "Ned Net", false));
		hunterPool.add(new Hunter(2, "Bill Brute", false));
		hunterPool.add(new Hunter(2, "Rongwae", false));
		hunterPool.add(new Hunter(1, "Louie", false));

		//Hunter ArrayList is shuffled at the beginning to make sure that player gets random hunters
		Collections.shuffle(hunterPool);
	}

	/**
	 * Add players during the beginning of the game
	     * @author Wonjohn Choi
	 */
	public void initializePlayers()
	{
		//declare and initialize Scanner variable 
		Scanner sc = new Scanner(System.in);
	
		
		/*
		//GUI covered
		//console message
		System.out.println("How many players are playing Elefant Hunt?");
		System.out.println("*Should be 2~3");
		
		//If # of players stored is not in range from 2 to 3,
		while(!(2<=numPlayer && numPlayer<=3))
		{
			//get # of players from user
			numPlayer = Integer.parseInt(sc.nextLine()); 
		}
		*/
		
		//create message to show to user
		String message = "How many players are playing Elefant Hunt?\n";
		message+=" ('Yes' = 2 | 'No' = 3)";
		
		//declare and initiate MessagePanel object to ask user the question
		MessagePanel msg = new MessagePanel(message);
		
		//variable to store user's response
		boolean isTwoPlayer = msg.onYNButtonClicked();
		
		//variable to store # of players
		int numPlayer=0;
		
		//if choice is yes,
		if(isTwoPlayer)
		{
			//# of players =2
			numPlayer = 2;
		}
		//if choice is no,
		else 
		{
			//# of players =3;
			numPlayer = 3;
		}
	
		//Create a temporarily array to store players WITHOUT order
		Player[] tmpPlayerPool = new Player[numPlayer];
	
		//GUI message
		sm.update("Please check the console!: you are required to fill the character's name");
		System.out.println("Use these names: Osgood, Erik, Paula");
		
		//for each iteration of # of players,
		for(int i = 0;i < numPlayer; i++)
		{
			//console message
			System.out.print("Name of Player "+(i+1)+": ");

	
			//initialize and store player objects to the temporary array 
			tmpPlayerPool[i] = new Player(sc.nextLine());
		}
	
		//console message
		System.out.println("\nRolling dies to decide the order of player among players");
	
		//initialize and declare an array to store the number that each  player gets by rolling a die
		int diePoints[] = new int[numPlayer];
	
		//for each iteration of # of players,
		for(int i = 0;i < numPlayer;i++)
		{
			//console message
			System.out.println(tmpPlayerPool[i].getName() + " rolled a die!");
	
			//store the arbitrary number from the function rollDie(); it should between 1 and 6 (inclusive)
			diePoints[i] = rollDie();
	
			//console message
			System.out.println(tmpPlayerPool[i].getName() + " got "+diePoints[i]);
		}
	
		//process below is used to determine who got the highest die score
		//,which will be used to decide the order of players.
		//When we store each object, we store them in the way that the player with higher die points are
		//stored at the head and player with lower die points are stored at the tail
	
		//initiate the ArrayList object to store the players in the order
		players = new ArrayList<Player>();
	
		//maxPoint will store the highest score 
		int maxPoint;
	
		//bestInx will store the player's index with the highest score
		int bestIdx;
	
		do
		{
			//Assign maxPoint using the lowest possible value 
			//Make bestPlayer as empty (null)
			maxPoint = Integer.MIN_VALUE;
			bestIdx = -1;
	
			//for each index of die points & players,
			for(int i =0;i<diePoints.length ;i++)
			{
				//if max point is lower than player's points
				if(tmpPlayerPool[i] != null && maxPoint < diePoints[i])
				{
					//update the highest point and best player's index
					maxPoint = diePoints[i];
					bestIdx = i;
				}
	
			}
	
			if(bestIdx!=-1)
			{
				//add the best player
				players.add(tmpPlayerPool[bestIdx]);
				tmpPlayerPool[bestIdx] = null;
			}
			//if no more player is detected, do the process again
		}while(bestIdx!=-1);
	}

	/**
	 * Initializes number of supplies available in the game
	 * @author Philip Markowski
	 */
	public void intializeSupplies() 
	{
		supplies = 54;
	}

	/**
	 * Initializes the animal pool for the game
	 * @author Philip Markowski
	 */
	public void initializeAnimals() 
	{
		animalPool = new ArrayList<Animal>();
	
		for (int i = 0; i < 5; i++) 
		{
			animalPool.add(new Animal(10, "Elefant", false));
		}
		animalPool.add(new Animal(16, "Mad Mom", true));
		animalPool.add(new Animal(6, "Baboon", false));
		animalPool.add(new Animal(5, "Python", false));
		animalPool.add(new Animal(8, "Giraffe", false));
		animalPool.add(new Animal(12, "Eagle", false));
		animalPool.add(new Animal(9, "Gorilla", false));
		animalPool.add(new Animal(7, "Hyena", false));
		animalPool.add(new Animal(7, "Antelope", false));
		animalPool.add(new Animal(8, "Crocodile", false));
		animalPool.add(new Animal(10, "Cheetah", false));
		animalPool.add(new Animal(5, "Aardvark", false));
		animalPool.add(new Animal(5, "Ostrich", false));
		animalPool.add(new Animal(6, "Zebra", false));
		animalPool.add(new Animal(9, "Lion", false));
		animalPool.add(new Animal(3, "Bush Baby", false));
		animalPool.add(new Animal(9, "Rhino", true));
		animalPool.add(new Animal(9, "Lion", true));
		animalPool.add(new Animal(8, "Crocodile", true));
		animalPool.add(new Animal(7, "Wart Hog", true));
	
		Collections.shuffle(animalPool);
	}

	/**
	 * Method that starts the game and controls general user messages
	 * @author Wonjohn Choi
	 * @throws InterruptedException 
	 */
	public void onStartGame() throws InterruptedException
	{
		//for each index,
		for(int i=0;i<players.size();i++)
		{   
			//get current player
			Player player = players.get(i);
	
			//hire the main hunter
			player.hireHunter(new Hunter(1, player.getName(), true));
	
			//console message
			sm.update("Main hunters are added");
		}
	
		
		//console message
		System.out.println("\nGame starts!\n");
		
		// GUI to tell uesrs that game starts
		sm.update("Game Starts!");
	
		//execute the actions of players (0th player starts first) - recursively calls next player
		onPlayerTurns(0);
	
		//declare and initialize a variable that will store winner Player
		Player winner = null;
	
		//for each player,
		for(Player player: players)
		{
			//if one's player is over the ending point,
			if(player.getPoints() >= ENDPOINT)
			{
				//set that he won!
				winner = player;
			}
		}
	
		//console meesage to show the final winner
		System.out.println(winner.getName() +" won the game with "+winner.getPoints()+" points");
		
		//GUI
		sm.update(winner.getName() +" won the game with "+winner.getPoints()+" points");
	
	}

	/**
	 * Method to call when player lands on a hunting space
	 * @param player
	 * @author Philip Markowski
	 * @throws InterruptedException 
	 */
	public void onHunt(Player player) throws InterruptedException 
	{
		if (animalPool.size() > 0)
		{
			int numAnimals = 0;
			Scanner sc = new Scanner(System.in);

			//Get the number of animals that will appear depending on the space
			if (map[player.getPosition()] == HUNT1) 
			{
				numAnimals = 1;
			} 
			else if (map[player.getPosition()] == HUNT2) 
			{
				numAnimals = 2;
			} 
			else if (map[player.getPosition()] == HUNT3) 
			{
				numAnimals = 3;
			}
			System.out.println(numAnimals + " animals appeared:");

			//Add as many animals that will appear to the array list
			ArrayList<Animal> hunted = new ArrayList<Animal>();
			for (int i = 0; i < numAnimals; i++)
			{
				hunted.add(animalPool.remove(0));
				System.out.println(hunted.get(i));
			}

			//Create array list of hunter arraylists
			ArrayList<ArrayList<Hunter>> huntingParties = new ArrayList<ArrayList<Hunter>>();
			//Call GUI method to choose hunters
			HuntingSpaces hs = new HuntingSpaces(player, hunted);
			huntingParties = hs.AssignHunters();
			//Do the combat
			for (int i = 0; i < numAnimals; i++)
			{
				//If animals are captured successfully add them to the player's animals
				if (isCaptured(hunted.get(i), huntingParties.get(i)))
				{
					System.out.println(player.getName() + " captured a " + hunted.get(i));
					sm.update(player.getName() + " captured a " + hunted.get(i));
					Thread.sleep(2000);
					player.addAnimal(hunted.get(i));
				}
				//If hunting fails and the animal is a predator, player must lose a hunter
				else if (hunted.get(i).isPredator() && player.numHunters() > 1)
				{
					System.out.println("Capture failed! Enter name of hunter to remove:");
					sm.update(player.getName() + " captured a " + hunted.get(i));
					Thread.sleep(2000);
					String hunter = sc.nextLine();
					player.fireHunter(hunter);
					animalPool.add(hunted.get(i));
				}
				//If hunting fails but the animal is not a predator, nothing happens
				else
				{
					System.out.println("Capture failed!");
					sm.update("Capture Failed!");
					Thread.sleep(2000);
					animalPool.add(hunted.get(i));
				}
				//Shuffle animal pool
				Collections.shuffle(animalPool);
			}
		}
		else
		{
			System.out.println("No more animals!");
			sm.update("No more animals exist in hunting places!");
			Thread.sleep(2000);
		}
	}

	/**
	 * Action happens when player lands on an empty space
	 * @param player the player who will act
	 * @author Wonjohn Choi
	 * @throws InterruptedException 
	 */
	public void onSpace(Player player) throws InterruptedException
	{
		//declare and initialize variables to store required supplies and owned supplies
		int requiredSupplies = player.numHunters(); //# of hunters indicate required supplies
		int ownedSupplies =player.getSupplies(); //# of suppplies each people own

		//if there is enough supplies,
		if(requiredSupplies <= ownedSupplies)
		{
			//player's # of supplies are updated
			player.setSupplies(ownedSupplies - requiredSupplies);

			//port gets the paid supplies
			supplies +=requiredSupplies;

			//console message
			System.out.println(player.getName()+"'s supplies decrease from "+ownedSupplies+"  to "+player.getSupplies());
			
			//GUI message
			sm.update(player.getName()+"'s supplies decrease from "+ownedSupplies+"  to "+player.getSupplies());
		}
		else 
		{
			//if there is not enough supplies, player's supplies become zero
			player.setSupplies(0);
			
			//GUI/console
			System.out.println("You do not have any supplies");
			sm.update("You do not have any supplies");
			Thread.sleep(2000);
			
			//port gets the paid supplies
			supplies +=ownedSupplies;

			//if there are any hunters other than the main hunters, 
			if(player.numHunters()>1)
			{
				//update console/GUI message
				System.out.println("You do not have enough supplies to feed your hunters");
				sm.update("You do not have enough supplies to feed your hunters");
				Thread.sleep(2000);
			
				//create message to tell user than he/she should fire some hunters
				String msg = "You should fire "+(player.numHunters()-ownedSupplies-1)+" hunters";
				
				//GUI/console message
				System.out.println(msg);
				sm.update(msg);
				Thread.sleep(2000);
				
				//create variable to store # of players to be fired
				int numFired =player.numHunters()-ownedSupplies-1;
				
				//for the required # of hunters,
				for(int i=0;i<numFired;i++)
				{
					//create GUI object to fire
					FireHunterNow fire = new FireHunterNow(player);
					
					//get the name of hunter to fire
					String name = fire.byeHunter();
					
					//fire the hunter by name using player's method
					//remember the hunter object using firedHunter variable
					Hunter firedHunter = player.fireHunter(name);
					sm.update("You fired "+firedHunter);
					
					//if the firedHunter exists,
					if(firedHunter!=null)
					{
						//add it to the hunterPool at port
						hunterPool.add(firedHunter);
					}
				}
				
				
				Thread.sleep(2000);

			}


		}

	}

	/**
	 * Action happens on port
	 * @param player player on action
	 * @author Wonjohn Choi
	 * @throws InterruptedException 
	 */
	public void onPort(Player player) throws InterruptedException
	{ 
		/* covered console message by GUI
		//console message
		System.out.println("Do you want to ");
		System.out.println("                        1. Get 4 extra supplies");
		System.out.println("                        2. Get an extra hunter");
		System.out.println("                        3. Roll a die to move");

		//receive the choice of user (1, 2, or 3)
		Scanner sc=new Scanner(System.in);
		int choice = sc.nextInt();*/

		//declare and initialize GUI object Options
		Options op = new Options();
		
		//Using op Object, you can get user's choice of what they want to do
		int choice = op.getButtonClicked();
		
		//if player asks for extra supplies,
		if(choice == 1)
		{
			//if supplies stored in port is enough,
			if(supplies >= 4)
			{
				//player's supplies increase by 4
				player.setSupplies(player.getSupplies() + 4);
				supplies-=4;

				//console message
				System.out.println("Total supplies: "+player.getSupplies()+" = "+(player.getSupplies()-4)+" + 4");
				
				//update GUI message
				sm.update("Total supplies: "+player.getSupplies()+" = "+(player.getSupplies()-4)+" + 4");
				Thread.sleep(2000);
			}
			//if supplies are not enough to give players,
			else
			{
				//console message
				System.out.println("There is not enough supplies stored on port: "+supplies);
				
				//update GUI message
				sm.update("There is not enough supplies stored on port: "+supplies);
				Thread.sleep(2000);

				//repeat question since there is not enough supplies
				onPort(player);
			}


		}
		//if player asks for extra hunter
		else if(choice == 2)
		{
			if(!hunterPool.isEmpty())
			{
				//take an hunter from port
				Hunter newHunter = hunterPool.remove(0);

				//player hires the hunter
				player.hireHunter(newHunter);

				//console message
				System.out.println(newHunter + " has been hired");
				
				//GUI update
				sm.update(newHunter + " has been hired");
				Thread.sleep(2000);
			}
			else
			{
				//console message
				System.out.println("There is not enough hunters left!");
				
				//GUI update
				sm.update("There is not enough hunters left!");
				Thread.sleep(2000);

				onPort(player);
			}
		}
		//if player wants to go for adventure,
		else if(choice == 3)
		{
			//roll a die and move
			rollAndMove(player);

			int pos = player.getPosition();
			
			//update gui
			guimap.repaint();
			

			//if landing location is an empty space,
			if(map[pos] == SPACE)
			{
				//Use method for action on an empty space
				onSpace(player);
			}
			//if landing location is a swamp,
			else if(map[pos] == SWAMP)
			{
				//Use method for action on a swamp.
				onSwamp(player);
			}

			//if landing location is a hunting place (other cases are covered above)
			else
			{
				//Do hunting
				onHunt(player);
			}
		}

	}

	/**
	 * Action happens on a player's turn
	 * @param player the player of subject
	 * @author Wonjohn Choi
	 * @throws InterruptedException 
	 */
	public void onPlayerTurns(int idx) throws InterruptedException
	{
		Player player = players.get(idx);
		System.out.println("************************************************");
		System.out.println(player.getName()+"'s turn starts!");
		
		//GUI stuff
		sm.update(player.getName()+"'s turn starts!");
		Thread.sleep(1000);
		
		//if player has hunters other than main,
		if(player.numHunters() >1)
		{
			//call a method to fire hunters that player want to fire
			onFireHunters(player);
		}


		//if player is on a port,
		if(map[player.getPosition()] == PORT)
		{
			//Use method for action on port
			onPort(player);
		}
		else //if it's not on port, 
		{
			//player is forced to roll and move.
			rollAndMove(player);
			
			//update gui
			guimap.repaint();
			
			//variable to store position of player
			int pos = player.getPosition();
			
			

			//if landing location is an empty space,
			if(map[pos] == SPACE)
			{
				//Use method for action on an empty space
				onSpace(player);
			}
			
			//if landing location is a swamp,
			else if(map[pos] == SWAMP)
			{
				//Use method for action on a swamp.
				onSwamp(player);
			}
			
			//if landing location is a port (it means that player finished a cycle)
			else if(map[pos] == PORT)
			{
				//if player has any animal,
				if(player.numAnimals() != 0)
				{
					//get captured animals of the player
					ArrayList<Animal> capturedAnimals = player.getAllAnimals();

					//if there is any animal left,
					while(capturedAnimals.size()!=0)
					{
						//remove the animal and convert them to points
						player.addPoints(capturedAnimals.remove(0).getLevel());
					}
				}

				//console & GUI messages
				System.out.println("Points updated: "+player.getPoints());
				sm.update("Points updated: "+player.getPoints());
				Thread.sleep(2000);
			}

			//if landing location is a hunting place (other cases are covered above)
			else
			{
				//Do hunting
				onHunt(player);
			}

		}

		//if the current player's score is under 100, player is not finished
		if(player.getPoints()<ENDPOINT)
		{
			//continue the turns using the next player
			onPlayerTurns((idx+1)%players.size());
		}
	}

	/**
	 * When a player lands on a swamp, if they have any animals, they lose one
	 * randomly, and if there are no animals they lose one supply, and if they
	 * have no supplies, nothing happens
	 * @param player
	 * @author Philip Markowski
	 * @throws InterruptedException 
	 */
	public void onSwamp(Player player) throws InterruptedException 
	{
		if (player.numAnimals() > 0) 
		{
			Animal removed =player.removeRandomAnimal();
			System.out.println("Player lost " + removed);
			sm.update("Player lost " + removed);
			Thread.sleep(2000);
		} 
		else if (player.getSupplies() > 0) 
		{
			player.setSupplies(player.getSupplies() - 1);
			System.out.println(player.getName() + "'s supplies decrease from "+(player.getSupplies()+1) + " to "+player.getSupplies());
			sm.update(player.getName() + "'s supplies decrease from "+(player.getSupplies()+1) + " to "+player.getSupplies());
			Thread.sleep(2000);
		}
		else
		{
			sm.update("Nothing happened!");
			Thread.sleep(1000);
		}
	}

	/**
	 * Ask player if he/she wants to fire hunters and fire them
	 * @param player who will fire hunters
	 * @throws InterruptedException 
	 */
	public void onFireHunters(Player player) throws InterruptedException
	{
	
		/* covered by gui
		Scanner sc = new Scanner(System.in);
		System.out.println("Do you want to fire any hunters prior to the start of your turn? (Y/N)");
		
		String choice = sc.next();*/

		//declare and initialize MessagePanel to ask question
		MessagePanel msg = new MessagePanel("Do you want to fire any hunters(Y/N)");
		
		//yes will be true/false if user click yes/no
		//create a variable called yes
		boolean yes = msg.onYNButtonClicked();
		
		//if user clicks yes,
		if(yes)
		{
			//console/GUI messages
			System.out.println("You chose to fire your hunters!");
			sm.update("You chose to fire your hunters!");
			
			//use FireHunterNow object to fire a hunter!
			FireHunterNow fire = new FireHunterNow(player);
			String name = fire.byeHunter();
			
			//use the name returned by byeHunter method to fire a hunter
			Hunter firedHunter = player.fireHunter(name);
			
			//if fired hunter exists,
			if(firedHunter!=null)
			{
				//add the hunter to the hunter pool on port
				hunterPool.add(firedHunter);
			}
			
			//GUI/console message
			System.out.println(name+" is fired by you!");
			sm.update(name+" is fired by you!");
			
			//if there are any hunters left other than main,
			if(player.numHunters()>1)
			{
				//ask again recursively 
				//Do not need to worry about StackOverFlow Exception as # of players are limited
				onFireHunters(player);	
			}
			
		}
		//if user clicks no,
		else 
		{
			//console message
			System.out.println("You chose not to fire any hunter.");
		}

	}

	/**
	 * String representation of this class: contains information about # of players, hunters, and animals
	 * @author Wonjohn Choi
	 */
	public String toString()
	{
		//String manipulation to include the required information
		String output = "";
		output+="# players = "+players.size();
		output+="/n# hunters = "+hunterPool.size();
		output+="/n# animals = "+animalPool.size();
	
		return output;
	}

	/**
	 * method to get a random number from 1 to 6
	 * @return the random number obtained
	 * @author Wonjohn Choi
	 */
	private int rollDie()
	{
		return (int)(Math.random()*6)+1;
	}

	/**
	 * get the name of location where player is located currently 
	 * solely for console message purpose
	 * @param player the player on subject
	 * @return the String representation of the location
	 * @author Wonjohn Choi
	 */
	private String getSiteName(Player player)
	{
		//variable to store the destination name
		String dest="";
	
		//variable to store position of player
		int pos = player.getPosition();
	
		//if player is on swamp,
		if(map[pos] == SWAMP)
		{
			dest = "swamp";
		}
		//if player is on an empty space,
		else if(map[pos] == SPACE)
		{
			dest = "empty space";
		}
		//if player is on a port,
		else if(map[pos] == PORT)
		{
			dest = "port";
		}
		//else - there are hunting places left
		else 
		{
			dest = "hunting place";
		}
	
		//return the destination
		return dest;
	}

	/**
	 * A method that contains messages for user when rolling a die and actually moves player to other place
	 * @param player the player who will roll a die and move
	 * @author Wonjohn Choi
	 * @throws InterruptedException 
	 */
	private void rollAndMove(Player player) throws InterruptedException
	{
		//create a variable to store the message that will be used for GUI
		String msg="";
		
		//console message
		System.out.println("Roll a die!");
		msg+="Rolled a die!";

		//get a random number between 1~6 using rollDie() method
		int dist = rollDie();

		//console message
		System.out.println("and got "+dist);
		msg+=" Got "+dist;
		
		//move player with the distance from the die
		player.move(dist);

		//console message to show where the player lands
		System.out.println("Arrived at "+getSiteName(player));
		msg+=(" Arrived at "+getSiteName(player));
		
		//update GUI message
		sm.update(msg);
		Thread.sleep(2000);
	}

	/**
	 * Checks to see if the animal is captured by the hunters given
	 * @param prey
	 * @param hunters
	 * @return Whether the animal is successfully captured or not
	 * @author Philip Markowski
	 */
	private boolean isCaptured(Animal prey, ArrayList<Hunter> hunters)
	{
		boolean isCaptured = false;

		//Roll die to see if animal gets away
		int roll = rollDie();
		System.out.println("Rolled a " + roll);

		if (roll > 1)
		{	
			//Add up total skill level of the hunters going after the animal
			int totalLvl = 0;
			for (int i = 0; i < hunters.size(); i++)
			{
				totalLvl = totalLvl + hunters.get(i).getLevel();
			}
			//If the total level plus the die roll is greater than the animal's level, it is captured, otherwise, the animal gets away
			if (prey.getLevel() <= totalLvl + roll)
			{
				System.out.println("Captured a " + prey.getName());
				isCaptured = true;
			}
			else if (prey.getLevel() > totalLvl + roll)
			{
				System.out.println(prey.getName() + " got away; skill too low");
				isCaptured = false;
			}
			//If a 1 is rolled, the animal automatically gets away 
		}
		else if (roll == 1)
		{
			System.out.println(prey.getName() + " got away");
			isCaptured = false;
		}

		return isCaptured;
	}


}
