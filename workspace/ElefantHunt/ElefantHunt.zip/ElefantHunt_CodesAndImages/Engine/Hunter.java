/**
 * @author Michael Valadao-Martins
 * @date June 4th, 2010
 * @supervisor Mr. Reid
 * @course ICS4U
 */
public class Hunter extends Item {
	private boolean isMain = false;

	public Hunter(int lvl, String name, boolean main) {
		super(lvl, name);
		isMain = main;
		/**
		 * @return calls original constructor
		 * @author Michael Valadao-Martins
		 */
	}

	public boolean isMain() {
		return isMain;
		/**
		 * @return isMain
		 */
	}

	public String toString() {
		
		String output = super.toString();
		
		if(isMain)
		{
			output = "Main Hunter " + output;
		}
		else
		{
			output = "Regular Hunter " + output;
		}
		return output;
	}
}
