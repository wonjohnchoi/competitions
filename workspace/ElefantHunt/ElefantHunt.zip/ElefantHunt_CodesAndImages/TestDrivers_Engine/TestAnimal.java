/**
 * @author Gerard Juan
 * @date June 5th, 2010
 * @supervisor Mr. Reid
 * @course ICS4U
 */
public class TestAnimal 
{
	public static void main(String[] args)
	{
		Animal a = new Animal(7, "Hyena", true);
		Animal b = new Animal(11, "Gorilla", false);
		Animal c = new Animal(15, "Jaguar", true);
		
		if (true)
		{
			System.out.println(a);
			System.out.println(b);
			System.out.println(c);
		}
	}
}
