/**
 * @author Michael Valadao-Martins
 * @date June 4th, 2010
 * @supervisor Mr. Reid
 * @course ICS4U
 */
public class TestHunter 
{
	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		Hunter a = new Hunter(5, "Marco", true);
		Hunter b = new Hunter(3, "Polo", false);	
		Hunter c = new Hunter(7, "Lolol", true);	
		/**
		 * @return the hunter
		 * @author Michael Valadao-Martins
		 */
		if (true)
		{
			System.out.println(a);
			System.out.println(b);
			System.out.println(c);
			/**
			 * @print main or sub hunter if it's true
			 * @author Michael Valadao-Martins
			 */
		}	
	}
}